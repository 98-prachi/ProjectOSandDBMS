function readStoredUser() {
  try {
    return JSON.parse(localStorage.getItem('user') || 'null');
  } catch (error) {
    if (error instanceof SyntaxError) {
      return null;
    }
    throw error;
  }
}

const state = {
  authMode: 'login',
  token: localStorage.getItem('token') || '',
  refreshToken: localStorage.getItem('refreshToken') || '',
  user: readStoredUser(),
  selectedEvent: null
};
const authForm = document.getElementById('authForm');
const dashboard = document.getElementById('dashboard');
const eventList = document.getElementById('eventList');
const seatList = document.getElementById('seatList');
const bookingList = document.getElementById('bookingList');
const eventCount = document.getElementById('eventCount');
const seatCount = document.getElementById('seatCount');
const bookingCount = document.getElementById('bookingCount');
const benchmarkPanel = document.getElementById('benchmarkPanel');
const benchmarkResult = document.getElementById('benchmarkResult');

function setAuthMode(mode) {
  state.authMode = mode;
  document.getElementById('loginTab').classList.toggle('active', mode === 'login');
  document.getElementById('registerTab').classList.toggle('active', mode === 'register');
  document.getElementById('nameField').classList.toggle('hidden', mode === 'login');
  document.getElementById('name').required = mode === 'register';
  document.getElementById('authSubmit').textContent = mode === 'login' ? 'Login' : 'Register';
}

function updateAuthUI() {
  const loggedIn = Boolean(state.token && state.user);
  dashboard.classList.toggle('hidden', !loggedIn);
  document.getElementById('logout').classList.toggle('hidden', !loggedIn);
  authForm.classList.toggle('hidden', loggedIn);
  benchmarkPanel.classList.toggle('hidden', !loggedIn || state.user.role !== 'ADMIN');
  if (!loggedIn) {
    setAuthMode('login');
  }
}

function storeSession(token, refreshToken, user) {
  state.token = token;
  state.refreshToken = refreshToken;
  state.user = user;
  localStorage.setItem('token', token);
  localStorage.setItem('refreshToken', refreshToken);
  localStorage.setItem('user', JSON.stringify(user));
  updateAuthUI();
}

function logout() {
  for (const key of ['token', 'refreshToken', 'user']) {
    localStorage.removeItem(key);
  }
  state.token = '';
  state.refreshToken = '';
  state.user = null;
  state.selectedEvent = null;
  updateAuthUI();
}

async function refreshSession() {
  const response = await fetch('/api/auth/refresh', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken: state.refreshToken })
  });
  if (!response.ok) {
    logout();
    return false;
  }
  const data = await response.json();
  storeSession(data.token, data.refreshToken, data.user);
  return true;
}

async function api(path, options = {}, retryAfterRefresh = true) {
  const headers = { ...(options.headers || {}) };
  if (state.token) {
    headers.Authorization = `Bearer ${state.token}`;
  }
  if (!headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  const response = await fetch(path, { ...options, headers });
  if (response.status === 401 && retryAfterRefresh && state.refreshToken && path !== '/api/auth/refresh') {
    if (await refreshSession()) {
      return api(path, options, false);
    }
  }
  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body && body.message ? body.message : 'Request failed. Please try again.');
  }
  return response.status === 204 ? null : response.json();
}

function appendText(parent, tagName, text, className) {
  const element = document.createElement(tagName);
  element.textContent = text;
  if (className) {
    element.className = className;
  }
  parent.appendChild(element);
  return element;
}

async function loadEvents() {
  const events = await api('/api/events');
  eventList.replaceChildren();
  eventCount.textContent = events.length;
  if (!events.length) {
    appendText(eventList, 'div', 'No events available.', 'event-card');
    return;
  }

  const selectedEvent = events.find(event => state.selectedEvent && event.id === state.selectedEvent.id) || events[0];
  state.selectedEvent = selectedEvent;
  for (const event of events) {
    const item = document.createElement('div');
    item.className = 'event-card';
    appendText(item, 'strong', event.name);
    appendText(item, 'div', event.venue);
    appendText(item, 'small', new Date(event.eventTime).toLocaleString());
    const button = appendText(item, 'button', 'Open seats');
    button.type = 'button';
    button.addEventListener('click', async () => {
      state.selectedEvent = event;
      try {
        await loadSeats(event.id);
      } catch (error) {
        alert(error.message);
      }
    });
    eventList.appendChild(item);
  }
  await loadSeats(selectedEvent.id);
}

async function loadSeats(eventId) {
  const seats = await api(`/api/events/${eventId}/seats`);
  seatList.replaceChildren();
  seatCount.textContent = seats.length;
  for (const seat of seats) {
    const button = appendText(seatList, 'button', `${seat.seatNumber} (${seat.status})`, `seat-card ${seat.status.toLowerCase()}`);
    button.type = 'button';
    button.disabled = seat.status !== 'AVAILABLE';
    if (!button.disabled) {
      button.addEventListener('click', async () => {
        try {
          const booking = await api('/api/bookings/hold', {
            method: 'POST',
            body: JSON.stringify({ eventId, seatId: seat.id })
          });
          alert(`Seat held: ${booking.seatNumber}`);
          await Promise.all([loadMyBookings(), loadSeats(eventId)]);
        } catch (error) {
          alert(error.message);
        }
      });
    }
  }
}

async function changeBooking(bookingId, action) {
  try {
    await api(`/api/bookings/${action}`, {
      method: 'POST',
      body: JSON.stringify({ bookingId })
    });
    await Promise.all([loadMyBookings(), loadEvents()]);
  } catch (error) {
    alert(error.message);
  }
}

async function loadMyBookings() {
  const bookings = await api('/api/bookings/me');
  bookingList.replaceChildren();
  bookingCount.textContent = bookings.length;
  if (!bookings.length) {
    appendText(bookingList, 'div', 'You have no bookings yet.', 'booking-item');
    return;
  }
  for (const booking of bookings) {
    const item = document.createElement('div');
    item.className = 'booking-item';
    appendText(item, 'strong', booking.status);
    appendText(item, 'div', `Seat: ${booking.seatNumber}`);
    appendText(item, 'div', new Date(booking.createdAt).toLocaleString());
    if (booking.status === 'HELD' && booking.expiresAt) {
      appendText(item, 'div', `Hold expires: ${new Date(booking.expiresAt).toLocaleString()}`);
      const confirmButton = appendText(item, 'button', 'Confirm');
      confirmButton.type = 'button';
      confirmButton.addEventListener('click', () => changeBooking(booking.bookingId, 'confirm'));
    }
    if (booking.status === 'HELD' || booking.status === 'CONFIRMED') {
      const cancelButton = appendText(item, 'button', 'Cancel');
      cancelButton.type = 'button';
      cancelButton.addEventListener('click', () => changeBooking(booking.bookingId, 'cancel'));
    }
    bookingList.appendChild(item);
  }
}

async function loginOrRegister(event) {
  event.preventDefault();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const name = document.getElementById('name').value.trim();
  const endpoint = state.authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
  const payload = state.authMode === 'login' ? { email, password } : { name, email, password };
  try {
    const data = await api(endpoint, { method: 'POST', body: JSON.stringify(payload) }, false);
    storeSession(data.token, data.refreshToken, data.user);
    await Promise.all([loadEvents(), loadMyBookings()]);
  } catch (error) {
    alert(error.message);
  }
}

async function runBenchmark() {
  const strategy = document.getElementById('benchmarkStrategy').value;
  const concurrency = Number(document.getElementById('benchmarkConcurrency').value);
  const attempts = Number(document.getElementById('benchmarkAttempts').value);
  try {
    const result = await api('/api/benchmark/run', {
      method: 'POST',
      body: JSON.stringify({
        strategy,
        concurrency,
        attemptsPerThread: attempts,
        eventId: state.selectedEvent ? state.selectedEvent.id : null
      })
    });
    benchmarkResult.textContent =
      `${result.strategy}: ${result.successCount} succeeded, ${result.failureCount} failed; ` +
      `${result.throughputPerSecond.toFixed(2)} operations/sec, ` +
      `${result.averageLatencyMs.toFixed(2)} ms average latency.`;
  } catch (error) {
    alert(error.message);
  }
}

function bindEvents() {
  document.getElementById('loginTab').addEventListener('click', () => setAuthMode('login'));
  document.getElementById('registerTab').addEventListener('click', () => setAuthMode('register'));
  document.getElementById('logout').addEventListener('click', logout);
  authForm.addEventListener('submit', loginOrRegister);
  document.getElementById('runBenchmarkBtn').addEventListener('click', runBenchmark);
}

async function bootstrap() {
  bindEvents();
  updateAuthUI();
  if (state.token && state.user) {
    try {
      await Promise.all([loadEvents(), loadMyBookings()]);
    } catch (error) {
      console.error(error);
    }
  }
}

bootstrap();
