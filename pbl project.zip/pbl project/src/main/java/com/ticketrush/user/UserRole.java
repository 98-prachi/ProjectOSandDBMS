package com.ticketrush.user;

public enum UserRole {
    USER,
    ADMIN
}
