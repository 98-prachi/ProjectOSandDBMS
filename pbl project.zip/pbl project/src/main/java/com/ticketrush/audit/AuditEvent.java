package com.ticketrush.audit;

import com.ticketrush.event.Event;
import com.ticketrush.event.Seat;
import com.ticketrush.user.User;
import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "audit_events")
public class AuditEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id")
    private Event event;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seat_id")
    private Seat seat;

    @Column(nullable = false)
    private String action;

    @Column(nullable = false)
    private String message;

    @Column(nullable = false)
    private Instant createdAt;

    protected AuditEvent() {}

    public AuditEvent(User user, Event event, Seat seat, String action, String message) {
        this.user = user;
        this.event = event;
        this.seat = seat;
        this.action = action;
        this.message = message;
        this.createdAt = Instant.now();
    }

    public Long getId() { return id; }
    public User getUser() { return user; }
    public Event getEvent() { return event; }
    public Seat getSeat() { return seat; }
    public String getAction() { return action; }
    public String getMessage() { return message; }
    public Instant getCreatedAt() { return createdAt; }
}
