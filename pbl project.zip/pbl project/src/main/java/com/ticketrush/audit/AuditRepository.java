package com.ticketrush.audit;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditRepository extends JpaRepository<AuditEvent, Long> {
    @EntityGraph(attributePaths = {"event", "seat"})
    List<AuditEvent> findByUserIdOrderByCreatedAtDesc(Long userId);

    @EntityGraph(attributePaths = {"event", "seat"})
    List<AuditEvent> findAllByOrderByCreatedAtDesc();
}
