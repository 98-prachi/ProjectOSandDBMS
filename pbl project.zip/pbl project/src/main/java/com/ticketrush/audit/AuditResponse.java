package com.ticketrush.audit;

import java.time.Instant;

public record AuditResponse(
    Long id,
    String action,
    String message,
    Instant createdAt,
    String eventName,
    String seatNumber) {
}
