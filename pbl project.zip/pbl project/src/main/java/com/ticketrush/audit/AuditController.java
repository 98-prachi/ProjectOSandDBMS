package com.ticketrush.audit;

import com.ticketrush.user.User;
import com.ticketrush.user.UserRepository;
import com.ticketrush.user.UserRole;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class AuditController {
    private final AuditRepository auditRepository;
    private final UserRepository userRepository;

    public AuditController(AuditRepository auditRepository, UserRepository userRepository) {
        this.auditRepository = auditRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/audit")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<AuditResponse>> audit(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        List<AuditEvent> events = user.getRole() == UserRole.ADMIN
            ? auditRepository.findAllByOrderByCreatedAtDesc()
            : auditRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
        List<AuditResponse> response = events.stream()
            .map(event -> new AuditResponse(
                event.getId(),
                event.getAction(),
                event.getMessage(),
                event.getCreatedAt(),
                event.getEvent() == null ? null : event.getEvent().getName(),
                event.getSeat() == null ? null : event.getSeat().getSeatNumber()))
            .toList();
        return ResponseEntity.ok(response);
    }
}
