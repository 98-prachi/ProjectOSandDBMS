package com.ticketrush.event;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "events")
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String venue;

    @Column(nullable = false)
    private Instant eventTime;

    @Column(nullable = false)
    private int totalSeats;

    protected Event() {}

    public Event(String name, String venue, Instant eventTime, int totalSeats) {
        this.name = name;
        this.venue = venue;
        this.eventTime = eventTime;
        this.totalSeats = totalSeats;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getVenue() { return venue; }
    public Instant getEventTime() { return eventTime; }
    public int getTotalSeats() { return totalSeats; }

    public void setName(String name) { this.name = name; }
    public void setVenue(String venue) { this.venue = venue; }
    public void setEventTime(Instant eventTime) { this.eventTime = eventTime; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }
}
