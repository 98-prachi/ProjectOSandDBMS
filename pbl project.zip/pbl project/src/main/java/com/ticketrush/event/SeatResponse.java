package com.ticketrush.event;

public record SeatResponse(Long id, String seatNumber, int price, SeatStatus status, long version) {
}
