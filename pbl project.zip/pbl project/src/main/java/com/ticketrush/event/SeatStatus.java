package com.ticketrush.event;

public enum SeatStatus {
    AVAILABLE,
    HELD,
    BOOKED
}
