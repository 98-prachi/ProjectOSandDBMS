package com.ticketrush.event;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class EventController {
    private final EventRepository eventRepository;
    private final SeatRepository seatRepository;

    public EventController(EventRepository eventRepository, SeatRepository seatRepository) {
        this.eventRepository = eventRepository;
        this.seatRepository = seatRepository;
    }

    @GetMapping("/events")
    public ResponseEntity<List<Event>> listEvents() {
        return ResponseEntity.ok(eventRepository.findAll());
    }

    @GetMapping("/events/{eventId}/seats")
    public ResponseEntity<List<SeatResponse>> listSeats(@PathVariable Long eventId) {
        List<SeatResponse> seats = seatRepository.findByEventIdOrderBySeatNumber(eventId).stream()
            .map(seat -> new SeatResponse(
                seat.getId(),
                seat.getSeatNumber(),
                seat.getPrice(),
                seat.getStatus(),
                seat.getVersion()))
            .toList();
        return ResponseEntity.ok(seats);
    }
}
