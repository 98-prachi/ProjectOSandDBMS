package com.ticketrush.event;

import com.ticketrush.user.User;
import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "seats", uniqueConstraints = { @UniqueConstraint(columnNames = {"event_id", "seat_number"}) },
    indexes = { @Index(name = "idx_seat_event_status", columnList = "event_id,status") })
public class Seat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;

    @Column(name = "seat_number", nullable = false)
    private String seatNumber;

    @Column(nullable = false)
    private int price;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SeatStatus status = SeatStatus.AVAILABLE;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "held_by")
    private User heldBy;

    @Column(name = "hold_expiry")
    private Instant holdExpiry;

    @Version
    private long version;

    protected Seat() {}

    public Seat(Event event, String seatNumber, int price) {
        this.event = event;
        this.seatNumber = seatNumber;
        this.price = price;
    }

    public Long getId() { return id; }
    public Event getEvent() { return event; }
    public String getSeatNumber() { return seatNumber; }
    public int getPrice() { return price; }
    public SeatStatus getStatus() { return status; }
    public User getHeldBy() { return heldBy; }
    public Instant getHoldExpiry() { return holdExpiry; }
    public long getVersion() { return version; }

    public void setEvent(Event event) { this.event = event; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }
    public void setPrice(int price) { this.price = price; }
    public void setStatus(SeatStatus status) { this.status = status; }
    public void setHeldBy(User heldBy) { this.heldBy = heldBy; }
    public void setHoldExpiry(Instant holdExpiry) { this.holdExpiry = holdExpiry; }
    public void setVersion(long version) { this.version = version; }
}
