package com.ticketrush.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI ticketRushOpenAPI() {
        return new OpenAPI().info(new Info()
            .title("TicketRush API")
            .description("Flash-sale ticket booking engine with optimistic and pessimistic locking benchmarks")
            .version("1.0.0"));
    }
}
