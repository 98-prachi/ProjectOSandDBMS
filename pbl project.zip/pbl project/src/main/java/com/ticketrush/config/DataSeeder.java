package com.ticketrush.config;

import com.ticketrush.event.Event;
import com.ticketrush.event.EventRepository;
import com.ticketrush.event.Seat;
import com.ticketrush.event.SeatRepository;
import com.ticketrush.user.User;
import com.ticketrush.user.UserRepository;
import com.ticketrush.user.UserRole;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.Instant;
import java.util.List;

@Configuration
public class DataSeeder {
    @Bean
    public CommandLineRunner seedDb(UserRepository userRepository, EventRepository eventRepository, SeatRepository seatRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.count() == 0) {
                User admin = userRepository.save(new User("Admin User", "admin@ticketrush.com", passwordEncoder.encode("admin123"), UserRole.ADMIN));
                userRepository.save(new User("Alice User", "alice@ticketrush.com", passwordEncoder.encode("password123"), UserRole.USER));
                System.out.println("Seeded default admin: " + admin.getEmail());
            }
            if (eventRepository.count() == 0) {
                Event event = eventRepository.save(new Event("Night Run Concert", "Delhi Stadium", Instant.now().plusSeconds(86400), 12));
                for (int i = 1; i <= 12; i++) {
                    seatRepository.save(new Seat(event, "A" + i, 500 + (i % 5) * 100));
                }
            }
        };
    }
}
