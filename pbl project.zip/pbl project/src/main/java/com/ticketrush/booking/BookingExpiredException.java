package com.ticketrush.booking;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class BookingExpiredException extends ResponseStatusException {
    public BookingExpiredException() {
        super(HttpStatus.CONFLICT, "Booking hold has expired");
    }
}
