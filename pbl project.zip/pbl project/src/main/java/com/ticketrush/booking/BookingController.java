package com.ticketrush.booking;

import com.ticketrush.user.User;
import com.ticketrush.user.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    private final BookingService bookingService;
    private final UserRepository userRepository;

    public BookingController(BookingService bookingService, UserRepository userRepository) {
        this.bookingService = bookingService;
        this.userRepository = userRepository;
    }

    @PostMapping("/hold")
    public ResponseEntity<BookingResponse> hold(@AuthenticationPrincipal UserDetails userDetails, @Valid @RequestBody BookingRequest request) {
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        return ResponseEntity.ok(bookingService.holdSeat(request.getEventId(), request.getSeatId(), user));
    }

    @PostMapping("/confirm")
    public ResponseEntity<BookingResponse> confirm(@AuthenticationPrincipal UserDetails userDetails, @Valid @RequestBody BookingConfirmationRequest request) {
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        return ResponseEntity.ok(bookingService.confirmBooking(request.getBookingId(), user));
    }

    @PostMapping("/cancel")
    public ResponseEntity<BookingResponse> cancel(@AuthenticationPrincipal UserDetails userDetails, @Valid @RequestBody BookingConfirmationRequest request) {
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        return ResponseEntity.ok(bookingService.cancelBooking(request.getBookingId(), user));
    }

    @GetMapping("/me")
    public ResponseEntity<List<BookingSummaryResponse>> myBookings(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        List<BookingSummaryResponse> bookings = bookingService.getBookingsForUser(user).stream()
            .map(booking -> new BookingSummaryResponse(
                booking.getId(),
                booking.getStatus(),
                booking.getSeat().getId(),
                booking.getSeat().getSeatNumber(),
                booking.getCreatedAt(),
                booking.getStatus() == BookingStatus.HELD ? booking.getSeat().getHoldExpiry() : null))
            .toList();
        return ResponseEntity.ok(bookings);
    }

    public static class BookingConfirmationRequest {
        @jakarta.validation.constraints.NotNull
        private Long bookingId;
        public Long getBookingId() { return bookingId; }
        public void setBookingId(Long bookingId) { this.bookingId = bookingId; }
    }
}
