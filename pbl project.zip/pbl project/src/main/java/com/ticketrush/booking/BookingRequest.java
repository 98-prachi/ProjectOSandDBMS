package com.ticketrush.booking;

import jakarta.validation.constraints.NotNull;

public class BookingRequest {
    @NotNull
    private Long eventId;
    @NotNull
    private Long seatId;

    public Long getEventId() { return eventId; }
    public void setEventId(Long eventId) { this.eventId = eventId; }
    public Long getSeatId() { return seatId; }
    public void setSeatId(Long seatId) { this.seatId = seatId; }
}
