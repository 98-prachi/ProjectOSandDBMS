package com.ticketrush.booking;

import com.ticketrush.audit.AuditEvent;
import com.ticketrush.audit.AuditRepository;
import com.ticketrush.common.ResourceNotFoundException;
import com.ticketrush.event.Event;
import com.ticketrush.event.EventRepository;
import com.ticketrush.event.Seat;
import com.ticketrush.event.SeatRepository;
import com.ticketrush.event.SeatStatus;
import com.ticketrush.user.User;
import org.springframework.http.HttpStatus;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.time.Duration;
import java.util.List;

@Service
public class BookingService {
    private static final Duration HOLD_DURATION = Duration.ofMinutes(3);

    private final BookingRepository bookingRepository;
    private final SeatRepository seatRepository;
    private final EventRepository eventRepository;
    private final AuditRepository auditRepository;

    public BookingService(BookingRepository bookingRepository, SeatRepository seatRepository, EventRepository eventRepository, AuditRepository auditRepository) {
        this.bookingRepository = bookingRepository;
        this.seatRepository = seatRepository;
        this.eventRepository = eventRepository;
        this.auditRepository = auditRepository;
    }

    @Transactional
    public BookingResponse holdSeat(Long eventId, Long seatId, User user) {
        Event event = eventRepository.findById(eventId).orElseThrow(() -> new ResourceNotFoundException("Event not found: " + eventId));
        Seat seat = seatRepository.findById(seatId).orElseThrow(() -> new ResourceNotFoundException("Seat not found: " + seatId));
        if (!seat.getEvent().getId().equals(eventId)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Seat does not belong to the event");
        }
        releaseExpiredHold(seat);
        if (seat.getStatus() != SeatStatus.AVAILABLE) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Seat is no longer available");
        }
        seat.setStatus(SeatStatus.HELD);
        seat.setHeldBy(user);
        seat.setHoldExpiry(Instant.now().plus(HOLD_DURATION));
        Seat savedSeat = seatRepository.saveAndFlush(seat);
        Booking booking = new Booking(user, savedSeat, BookingStatus.HELD);
        Booking saved = bookingRepository.save(booking);
        auditRepository.save(new AuditEvent(user, event, savedSeat, "SEAT_HELD", "Seat " + savedSeat.getSeatNumber() + " held for user " + user.getEmail()));
        return new BookingResponse(saved.getId(), savedSeat.getId(), savedSeat.getSeatNumber(), BookingStatus.HELD, savedSeat.getHoldExpiry());
    }

    @Transactional
    public BookingResponse holdSeatPessimistic(Long eventId, Long seatId, User user) {
        Event event = eventRepository.findById(eventId).orElseThrow(() -> new ResourceNotFoundException("Event not found: " + eventId));
        Seat seat = seatRepository.findByIdForUpdate(seatId).orElseThrow(() -> new ResourceNotFoundException("Seat not found: " + seatId));
        if (!seat.getEvent().getId().equals(eventId)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Seat does not belong to the event");
        }
        releaseExpiredHold(seat);
        if (seat.getStatus() != SeatStatus.AVAILABLE) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Seat is no longer available");
        }
        seat.setStatus(SeatStatus.HELD);
        seat.setHeldBy(user);
        seat.setHoldExpiry(Instant.now().plus(HOLD_DURATION));
        Seat savedSeat = seatRepository.saveAndFlush(seat);
        Booking booking = new Booking(user, savedSeat, BookingStatus.HELD);
        Booking saved = bookingRepository.save(booking);
        auditRepository.save(new AuditEvent(user, event, savedSeat, "SEAT_HELD_PESSIMISTIC", "Seat " + savedSeat.getSeatNumber() + " held under pessimistic lock"));
        return new BookingResponse(saved.getId(), savedSeat.getId(), savedSeat.getSeatNumber(), BookingStatus.HELD, savedSeat.getHoldExpiry());
    }

    @Transactional(noRollbackFor = BookingExpiredException.class)
    public BookingResponse confirmBooking(Long bookingId, User user) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));
        if (!booking.getUser().getId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You cannot confirm another user’s booking");
        }
        Seat seat = booking.getSeat();
        if (isExpiredHold(booking, seat, Instant.now())) {
            expireBooking(booking, seat, user);
            throw new BookingExpiredException();
        }
        if (booking.getStatus() != BookingStatus.HELD || seat.getStatus() != SeatStatus.HELD) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Booking is not in a held state");
        }
        seat.setStatus(SeatStatus.BOOKED);
        seat.setHeldBy(null);
        seat.setHoldExpiry(null);
        booking.setStatus(BookingStatus.CONFIRMED);
        bookingRepository.save(booking);
        seatRepository.save(seat);
        auditRepository.save(new AuditEvent(user, seat.getEvent(), seat, "BOOKING_CONFIRMED", "Seat " + seat.getSeatNumber() + " confirmed"));
        return new BookingResponse(booking.getId(), seat.getId(), seat.getSeatNumber(), BookingStatus.CONFIRMED, null);
    }

    @Transactional(noRollbackFor = BookingExpiredException.class)
    public BookingResponse cancelBooking(Long bookingId, User user) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));
        if (!booking.getUser().getId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You cannot cancel another user’s booking");
        }
        Seat seat = booking.getSeat();
        if (isExpiredHold(booking, seat, Instant.now())) {
            expireBooking(booking, seat, user);
            throw new BookingExpiredException();
        }
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Booking already cancelled");
        }
        if (booking.getStatus() == BookingStatus.EXPIRED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Booking has expired");
        }
        seat.setStatus(SeatStatus.AVAILABLE);
        seat.setHeldBy(null);
        seat.setHoldExpiry(null);
        booking.setStatus(BookingStatus.CANCELLED);
        bookingRepository.save(booking);
        seatRepository.save(seat);
        auditRepository.save(new AuditEvent(user, seat.getEvent(), seat, "BOOKING_CANCELLED", "Seat " + seat.getSeatNumber() + " cancelled"));
        return new BookingResponse(booking.getId(), seat.getId(), seat.getSeatNumber(), BookingStatus.CANCELLED, null);
    }

    public List<Booking> getBookingsForUser(User user) {
        return bookingRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
    }

    private void releaseExpiredHold(Seat seat) {
        Instant now = Instant.now();
        if (seat.getStatus() != SeatStatus.HELD || seat.getHoldExpiry() == null || seat.getHoldExpiry().isAfter(now)) {
            return;
        }
        bookingRepository.findFirstBySeatIdAndStatusOrderByCreatedAtDesc(seat.getId(), BookingStatus.HELD)
            .ifPresent(booking -> {
                booking.setStatus(BookingStatus.EXPIRED);
                auditRepository.save(new AuditEvent(
                    booking.getUser(),
                    seat.getEvent(),
                    seat,
                    "BOOKING_EXPIRED",
                    "Seat " + seat.getSeatNumber() + " hold expired"));
            });
        seat.setStatus(SeatStatus.AVAILABLE);
        seat.setHeldBy(null);
        seat.setHoldExpiry(null);
    }

    private boolean isExpiredHold(Booking booking, Seat seat, Instant now) {
        return booking.getStatus() == BookingStatus.HELD
            && seat.getStatus() == SeatStatus.HELD
            && seat.getHoldExpiry() != null
            && !seat.getHoldExpiry().isAfter(now);
    }

    private void expireBooking(Booking booking, Seat seat, User user) {
        booking.setStatus(BookingStatus.EXPIRED);
        seat.setStatus(SeatStatus.AVAILABLE);
        seat.setHeldBy(null);
        seat.setHoldExpiry(null);
        bookingRepository.save(booking);
        seatRepository.save(seat);
        auditRepository.save(new AuditEvent(
            user,
            seat.getEvent(),
            seat,
            "BOOKING_EXPIRED",
            "Seat " + seat.getSeatNumber() + " hold expired"));
    }
}
