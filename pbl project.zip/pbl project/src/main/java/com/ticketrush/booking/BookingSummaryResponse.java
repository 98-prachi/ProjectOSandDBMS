package com.ticketrush.booking;

import java.time.Instant;

public record BookingSummaryResponse(
    Long bookingId,
    BookingStatus status,
    Long seatId,
    String seatNumber,
    Instant createdAt,
    Instant expiresAt) {
}
