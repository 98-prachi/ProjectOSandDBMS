package com.ticketrush.booking;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    @EntityGraph(attributePaths = "seat")
    List<Booking> findByUserIdOrderByCreatedAtDesc(Long userId);

    Optional<Booking> findFirstBySeatIdAndStatusOrderByCreatedAtDesc(Long seatId, BookingStatus status);
}
