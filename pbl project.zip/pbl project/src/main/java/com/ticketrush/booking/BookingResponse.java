package com.ticketrush.booking;

import java.time.Instant;

public class BookingResponse {
    private Long bookingId;
    private Long seatId;
    private String seatNumber;
    private String status;
    private Instant expiresAt;

    public BookingResponse(Long bookingId, Long seatId, String seatNumber, BookingStatus status, Instant expiresAt) {
        this.bookingId = bookingId;
        this.seatId = seatId;
        this.seatNumber = seatNumber;
        this.status = status.name();
        this.expiresAt = expiresAt;
    }

    public Long getBookingId() { return bookingId; }
    public Long getSeatId() { return seatId; }
    public String getSeatNumber() { return seatNumber; }
    public String getStatus() { return status; }
    public Instant getExpiresAt() { return expiresAt; }
}
