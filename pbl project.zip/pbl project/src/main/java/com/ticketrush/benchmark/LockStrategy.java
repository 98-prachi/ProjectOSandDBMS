package com.ticketrush.benchmark;

public enum LockStrategy {
    OPTIMISTIC,
    PESSIMISTIC
}
