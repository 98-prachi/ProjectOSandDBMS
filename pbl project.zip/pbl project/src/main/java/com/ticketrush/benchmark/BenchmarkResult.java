package com.ticketrush.benchmark;

public class BenchmarkResult {
    private final LockStrategy strategy;
    private final int successCount;
    private final int failureCount;
    private final double throughputPerSecond;
    private final double averageLatencyMs;

    public BenchmarkResult(LockStrategy strategy, int successCount, int failureCount, double throughputPerSecond, double averageLatencyMs) {
        this.strategy = strategy;
        this.successCount = successCount;
        this.failureCount = failureCount;
        this.throughputPerSecond = throughputPerSecond;
        this.averageLatencyMs = averageLatencyMs;
    }

    public LockStrategy getStrategy() { return strategy; }
    public int getSuccessCount() { return successCount; }
    public int getFailureCount() { return failureCount; }
    public double getThroughputPerSecond() { return throughputPerSecond; }
    public double getAverageLatencyMs() { return averageLatencyMs; }
}
