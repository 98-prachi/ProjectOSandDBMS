package com.ticketrush.benchmark;

import com.ticketrush.user.User;
import com.ticketrush.user.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class BenchmarkController {
    private final BenchmarkService benchmarkService;
    private final UserRepository userRepository;

    public BenchmarkController(BenchmarkService benchmarkService, UserRepository userRepository) {
        this.benchmarkService = benchmarkService;
        this.userRepository = userRepository;
    }

    @PostMapping("/benchmark/run")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BenchmarkResult> run(@AuthenticationPrincipal UserDetails userDetails, @Valid @RequestBody BenchmarkRequest request) {
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        return ResponseEntity.ok(benchmarkService.runBenchmark(request, user));
    }
}
