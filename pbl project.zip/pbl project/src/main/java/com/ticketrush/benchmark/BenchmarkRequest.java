package com.ticketrush.benchmark;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public class BenchmarkRequest {
    private LockStrategy strategy;
    @Min(1)
    @Max(20)
    private int concurrency = 8;
    @Min(1)
    @Max(30)
    private int attemptsPerThread = 10;
    private Long eventId;

    public LockStrategy getStrategy() { return strategy; }
    public void setStrategy(LockStrategy strategy) { this.strategy = strategy; }
    public int getConcurrency() { return concurrency; }
    public void setConcurrency(int concurrency) { this.concurrency = concurrency; }
    public int getAttemptsPerThread() { return attemptsPerThread; }
    public void setAttemptsPerThread(int attemptsPerThread) { this.attemptsPerThread = attemptsPerThread; }
    public Long getEventId() { return eventId; }
    public void setEventId(Long eventId) { this.eventId = eventId; }
}
