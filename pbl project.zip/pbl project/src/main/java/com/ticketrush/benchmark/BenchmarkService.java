package com.ticketrush.benchmark;

import com.ticketrush.booking.BookingService;
import com.ticketrush.common.ResourceNotFoundException;
import com.ticketrush.event.Event;
import com.ticketrush.event.EventRepository;
import com.ticketrush.event.Seat;
import com.ticketrush.event.SeatRepository;
import com.ticketrush.user.User;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.LongAdder;

@Service
public class BenchmarkService {
    private static final long WORKER_TIMEOUT_SECONDS = 60;

    private final BookingService bookingService;
    private final EventRepository eventRepository;
    private final SeatRepository seatRepository;

    public BenchmarkService(BookingService bookingService, EventRepository eventRepository, SeatRepository seatRepository) {
        this.bookingService = bookingService;
        this.eventRepository = eventRepository;
        this.seatRepository = seatRepository;
    }

    public BenchmarkResult runBenchmark(BenchmarkRequest request, User user) {
        Long eventId = request.getEventId() != null
            ? request.getEventId()
            : eventRepository.findAll().stream().findFirst()
                .map(Event::getId)
                .orElseThrow(() -> new ResourceNotFoundException("No event found"));
        List<Long> seatIds = seatRepository.findByEventIdOrderBySeatNumber(eventId).stream()
            .map(Seat::getId)
            .toList();
        if (seatIds.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No seats available for benchmarking");
        }

        LockStrategy strategy = request.getStrategy() == null ? LockStrategy.OPTIMISTIC : request.getStrategy();
        int concurrency = request.getConcurrency();
        int attemptsPerThread = request.getAttemptsPerThread();
        ExecutorService pool = Executors.newFixedThreadPool(concurrency);
        CountDownLatch readyLatch = new CountDownLatch(concurrency);
        CountDownLatch startLatch = new CountDownLatch(1);
        LongAdder totalLatencyNanos = new LongAdder();
        List<Future<WorkerResult>> workers = java.util.stream.IntStream.range(0, concurrency)
            .mapToObj(threadIndex -> pool.submit(() -> runWorker(
                threadIndex,
                attemptsPerThread,
                eventId,
                seatIds,
                strategy,
                user,
                readyLatch,
                startLatch,
                totalLatencyNanos)))
            .toList();

        long startNanos;
        try {
            readyLatch.await();
            startNanos = System.nanoTime();
            startLatch.countDown();
            pool.shutdown();
            WorkerResult totals = collectResults(workers);
            long elapsedNanos = Math.max(1, System.nanoTime() - startNanos);
            int totalAttempts = totals.successful() + totals.failed();
            double elapsedSeconds = elapsedNanos / 1_000_000_000.0;
            double throughputPerSecond = totalAttempts / elapsedSeconds;
            double averageLatencyMs = totalAttempts == 0
                ? 0
                : totalLatencyNanos.sum() / 1_000_000.0 / totalAttempts;
            return new BenchmarkResult(strategy, totals.successful(), totals.failed(), throughputPerSecond, averageLatencyMs);
        } catch (InterruptedException ex) {
            pool.shutdownNow();
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Benchmark interrupted before completion", ex);
        } catch (RuntimeException ex) {
            pool.shutdownNow();
            throw ex;
        }
    }

    private WorkerResult runWorker(
        int threadIndex,
        int attemptsPerThread,
        Long eventId,
        List<Long> seatIds,
        LockStrategy strategy,
        User user,
        CountDownLatch readyLatch,
        CountDownLatch startLatch,
        LongAdder totalLatencyNanos) throws InterruptedException {
        readyLatch.countDown();
        startLatch.await();
        int successful = 0;
        int failed = 0;
        for (int attempt = 0; attempt < attemptsPerThread; attempt++) {
            Long seatId = seatIds.get((threadIndex + attempt) % seatIds.size());
            long attemptStarted = System.nanoTime();
            try {
                if (strategy == LockStrategy.PESSIMISTIC) {
                    bookingService.holdSeatPessimistic(eventId, seatId, user);
                } else {
                    bookingService.holdSeat(eventId, seatId, user);
                }
                successful++;
            } catch (ResponseStatusException ex) {
                if (ex.getStatusCode() != HttpStatus.CONFLICT) {
                    throw ex;
                }
                failed++;
            } catch (OptimisticLockingFailureException | PessimisticLockingFailureException ex) {
                failed++;
            } finally {
                totalLatencyNanos.add(System.nanoTime() - attemptStarted);
            }
        }
        return new WorkerResult(successful, failed);
    }

    private WorkerResult collectResults(List<Future<WorkerResult>> workers) throws InterruptedException {
        int successful = 0;
        int failed = 0;
        try {
            for (Future<WorkerResult> worker : workers) {
                WorkerResult result = worker.get(WORKER_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                successful += result.successful();
                failed += result.failed();
            }
        } catch (ExecutionException ex) {
            throw new IllegalStateException("Benchmark worker failed", ex.getCause());
        } catch (TimeoutException ex) {
            throw new IllegalStateException("Benchmark workers did not finish in time", ex);
        }
        return new WorkerResult(successful, failed);
    }

    private record WorkerResult(int successful, int failed) {
    }
}
