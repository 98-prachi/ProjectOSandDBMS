package com.ticketrush.auth;

import com.ticketrush.audit.AuditEvent;
import com.ticketrush.audit.AuditRepository;
import com.ticketrush.security.JwtService;
import com.ticketrush.user.RefreshToken;
import com.ticketrush.user.RefreshTokenRepository;
import com.ticketrush.user.User;
import com.ticketrush.user.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.Duration;
import java.util.Base64;
import java.util.UUID;

@Service
public class AuthService {
    private static final int MAX_FAILED_LOGINS = 5;
    private static final Duration LOGIN_LOCK_DURATION = Duration.ofMinutes(15);

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final AuditRepository auditRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository, RefreshTokenRepository refreshTokenRepository, AuditRepository auditRepository, PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager, JwtService jwtService) {
        this.userRepository = userRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.auditRepository = auditRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        String email = request.getEmail().trim().toLowerCase();
        if (userRepository.existsByEmail(email)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
        }
        User user = new User(request.getName().trim(), email, passwordEncoder.encode(request.getPassword()), com.ticketrush.user.UserRole.USER);
        user = userRepository.save(user);
        auditRepository.save(new AuditEvent(user, null, null, "USER_REGISTERED", "User registered"));
        String refreshToken = createRefreshToken(user);
        return new AuthResponse(jwtService.generateToken(user.getEmail()), refreshToken, user);
    }

    @Transactional(noRollbackFor = InvalidLoginException.class)
    public AuthResponse login(LoginRequest request) {
        String email = request.getEmail().trim().toLowerCase();
        User user = userRepository.findByEmail(email).orElse(null);
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, request.getPassword()));
        } catch (AuthenticationException ex) {
            recordLoginFailure(user);
            throw new InvalidLoginException();
        }
        if (user == null) {
            recordLoginFailure(null);
            throw new InvalidLoginException();
        }
        user.setFailedLoginCount(0);
        user.setLockedUntil(null);
        auditRepository.save(new AuditEvent(user, null, null, "LOGIN_SUCCEEDED", "User logged in"));
        String refreshToken = createRefreshToken(user);
        return new AuthResponse(jwtService.generateToken(user.getEmail()), refreshToken, user);
    }

    @Transactional
    public AuthResponse refreshToken(RefreshTokenRequest request) {
        String rawRefresh = request.getRefreshToken();
        if (rawRefresh == null || rawRefresh.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Refresh token missing");
        }
        String hash = hashToken(rawRefresh);
        RefreshToken refreshToken = refreshTokenRepository.findByTokenHash(hash).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid refresh token"));
        if (refreshToken.isRevoked() || refreshToken.getExpiry().isBefore(Instant.now())) {
            refreshToken.setRevoked(true);
            refreshTokenRepository.save(refreshToken);
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Refresh token expired");
        }
        User user = refreshToken.getUser();
        refreshToken.setRevoked(true);
        refreshTokenRepository.save(refreshToken);
        auditRepository.save(new AuditEvent(user, null, null, "REFRESH_TOKEN_ROTATED", "Refresh token rotated"));
        String newRefresh = createRefreshToken(user);
        return new AuthResponse(jwtService.generateToken(user.getEmail()), newRefresh, user);
    }

    private void recordLoginFailure(User user) {
        Instant now = Instant.now();
        if (user != null) {
            if (user.getLockedUntil() != null && !user.getLockedUntil().isAfter(now)) {
                user.setFailedLoginCount(0);
                user.setLockedUntil(null);
            }
            if (user.getLockedUntil() == null) {
                int failedAttempts = user.getFailedLoginCount() + 1;
                user.setFailedLoginCount(failedAttempts);
                if (failedAttempts >= MAX_FAILED_LOGINS) {
                    user.setLockedUntil(now.plus(LOGIN_LOCK_DURATION));
                }
            }
        }
        auditRepository.save(new AuditEvent(user, null, null, "LOGIN_FAILED", "Login failed"));
    }

    private String createRefreshToken(User user) {
        String rawToken = UUID.randomUUID().toString();
        RefreshToken refreshToken = new RefreshToken(user, hashToken(rawToken), Instant.now().plusSeconds(7L * 24 * 60 * 60));
        refreshTokenRepository.save(refreshToken);
        return rawToken;
    }

    private String hashToken(String token) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(token.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to hash refresh token", ex);
        }
    }
}
