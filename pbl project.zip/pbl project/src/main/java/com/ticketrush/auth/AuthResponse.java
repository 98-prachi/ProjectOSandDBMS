package com.ticketrush.auth;

import com.ticketrush.user.User;

public class AuthResponse {
    private String token;
    private String refreshToken;
    private UserSummary user;

    public AuthResponse(String token, String refreshToken, User user) {
        this.token = token;
        this.refreshToken = refreshToken;
        this.user = new UserSummary(user.getId(), user.getName(), user.getEmail(), user.getRole().name());
    }

    public String getToken() { return token; }
    public String getRefreshToken() { return refreshToken; }
    public UserSummary getUser() { return user; }

    public static class UserSummary {
        private Long id;
        private String name;
        private String email;
        private String role;

        public UserSummary(Long id, String name, String email, String role) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.role = role;
        }

        public Long getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
    }
}
