package com.ticketrush;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.sql.Timestamp;
import java.time.Instant;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("h2")
class TicketRushIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    void publicFrontendAndAssetsAreAccessibleWithoutAuthentication() throws Exception {
        mockMvc.perform(get("/"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/index.html"))
            .andExpect(status().isOk())
            .andExpect(content().string(containsString("<title>TicketRush</title>")));

        mockMvc.perform(get("/app.js"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/styles.css"))
            .andExpect(status().isOk());
    }

    @Test
    void registeredUserCanBookAndManageOwnSeatWithoutLeakingEntities() throws Exception {
        String token = register("ticket-rush-user@example.com");

        mockMvc.perform(get("/api/events"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].name").isNotEmpty());

        long seatId = getAvailableSeatId();
        MvcResult seatsResult = mockMvc.perform(get("/api/events/1/seats"))
            .andExpect(status().isOk())
            .andReturn();
        JsonNode seats = objectMapper.readTree(seatsResult.getResponse().getContentAsString());
        JsonNode availableSeat = null;
        for (JsonNode seat : seats) {
            if (seat.get("id").asLong() == seatId) {
                availableSeat = seat;
                break;
            }
        }
        assertNotNull(availableSeat);
        assertEquals("AVAILABLE", availableSeat.get("status").asText());
        assertFalse(availableSeat.has("heldBy"));
        assertFalse(availableSeat.has("event"));

        MvcResult holdResult = mockMvc.perform(post("/api/bookings/hold")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventId\":1,\"seatId\":" + seatId + "}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("HELD"))
            .andReturn();
        long bookingId = objectMapper.readTree(holdResult.getResponse().getContentAsString())
            .get("bookingId").asLong();

        mockMvc.perform(get("/api/bookings/me")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].bookingId").value(bookingId))
            .andExpect(jsonPath("$[0].seatNumber").isNotEmpty())
            .andExpect(jsonPath("$[0].user").doesNotExist())
            .andExpect(jsonPath("$[0].password").doesNotExist());

        mockMvc.perform(post("/api/bookings/confirm")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"bookingId\":" + bookingId + "}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("CONFIRMED"));

        mockMvc.perform(post("/api/bookings/cancel")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"bookingId\":" + bookingId + "}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("CANCELLED"));

        mockMvc.perform(get("/api/audit")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].action").isNotEmpty())
            .andExpect(jsonPath("$[0].user").doesNotExist());
    }

    @Test
    void bookingEndpointsRequireAuthenticationAndValidateRequests() throws Exception {
        mockMvc.perform(post("/api/bookings/hold")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventId\":1,\"seatId\":1}"))
            .andExpect(status().isUnauthorized());

        String token = register("validation-user@example.com");
        mockMvc.perform(post("/api/bookings/hold")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventId\":null,\"seatId\":1}"))
            .andExpect(status().isBadRequest());
    }

    @Test
    void expiredHoldIsReleasedAndCannotBeConfirmed() throws Exception {
        String token = register("expired-hold-user@example.com");
        long seatId = getAvailableSeatId();
        MvcResult holdResult = mockMvc.perform(post("/api/bookings/hold")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventId\":1,\"seatId\":" + seatId + "}"))
            .andExpect(status().isOk())
            .andReturn();
        long bookingId = objectMapper.readTree(holdResult.getResponse().getContentAsString())
            .get("bookingId").asLong();

        jdbcTemplate.update(
            "UPDATE seats SET hold_expiry = ? WHERE id = ?",
            Timestamp.from(Instant.now().minusSeconds(1)),
            seatId);

        mockMvc.perform(post("/api/bookings/confirm")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"bookingId\":" + bookingId + "}"))
            .andExpect(status().isConflict());

        mockMvc.perform(get("/api/events/1/seats"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[?(@.id == " + seatId + ")].status").value("AVAILABLE"));
        mockMvc.perform(get("/api/bookings/me")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].status").value("EXPIRED"));
    }

    @Test
    void failedLoginIsAuditedAndInvalidBearerTokensAreUnauthorized() throws Exception {
        String token = register("audit-login-user@example.com");
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"audit-login-user@example.com\",\"password\":\"wrong-password\"}"))
            .andExpect(status().isUnauthorized());

        mockMvc.perform(get("/api/audit")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andExpect(content().string(containsString("LOGIN_FAILED")));
        mockMvc.perform(get("/api/bookings/me")
                .header("Authorization", "Bearer invalid"))
            .andExpect(status().isUnauthorized());
    }

    @Test
    void usersCannotManageOtherUsersBookingsOrRunAdminBenchmarks() throws Exception {
        String ownerToken = register("booking-owner@example.com");
        String otherToken = register("other-user@example.com");
        long seatId = getAvailableSeatId();
        MvcResult holdResult = mockMvc.perform(post("/api/bookings/hold")
                .header("Authorization", "Bearer " + ownerToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventId\":1,\"seatId\":" + seatId + "}"))
            .andExpect(status().isOk())
            .andReturn();
        long bookingId = objectMapper.readTree(holdResult.getResponse().getContentAsString())
            .get("bookingId").asLong();

        mockMvc.perform(post("/api/bookings/confirm")
                .header("Authorization", "Bearer " + otherToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"bookingId\":" + bookingId + "}"))
            .andExpect(status().isForbidden());

        mockMvc.perform(post("/api/benchmark/run")
                .header("Authorization", "Bearer " + otherToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"strategy\":\"OPTIMISTIC\",\"concurrency\":1,\"attemptsPerThread\":1,\"eventId\":1}"))
            .andExpect(status().isForbidden());
    }

    @Test
    void adminBenchmarkReturnsMeasuredAttemptCountsAndTimings() throws Exception {
        MvcResult loginResult = mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"admin@ticketrush.com\",\"password\":\"admin123\"}"))
            .andExpect(status().isOk())
            .andReturn();
        String adminToken = objectMapper.readTree(loginResult.getResponse().getContentAsString())
            .get("token").asText();

        MvcResult benchmarkResult = mockMvc.perform(post("/api/benchmark/run")
                .header("Authorization", "Bearer " + adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"strategy\":\"OPTIMISTIC\",\"concurrency\":2,\"attemptsPerThread\":2,\"eventId\":1}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.throughputPerSecond").isNumber())
            .andExpect(jsonPath("$.averageLatencyMs").isNumber())
            .andReturn();
        JsonNode result = objectMapper.readTree(benchmarkResult.getResponse().getContentAsString());
        assertEquals(
            4,
            result.get("successCount").asInt() + result.get("failureCount").asInt());
        assertTrue(result.get("throughputPerSecond").asDouble() > 0);
    }

    private String register(String email) throws Exception {
        MvcResult result = mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Integration User\",\"email\":\"" + email + "\",\"password\":\"test-password-123\"}"))
            .andExpect(status().isOk())
            .andReturn();
        return objectMapper.readTree(result.getResponse().getContentAsString()).get("token").asText();
    }

    private long getAvailableSeatId() throws Exception {
        MvcResult result = mockMvc.perform(get("/api/events/1/seats"))
            .andExpect(status().isOk())
            .andReturn();
        for (JsonNode seat : objectMapper.readTree(result.getResponse().getContentAsString())) {
            if ("AVAILABLE".equals(seat.get("status").asText())) {
                return seat.get("id").asLong();
            }
        }
        throw new AssertionError("Expected an available seeded seat");
    }
}
