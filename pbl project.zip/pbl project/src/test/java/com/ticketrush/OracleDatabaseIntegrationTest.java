package com.ticketrush;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ActiveProfiles("oracle")
@EnabledIfSystemProperty(named = "ticketrush.oracle.integration", matches = "true")
class OracleDatabaseIntegrationTest {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    void oracleMigrationsAndApplicationSeedingComplete() {
        Integer eventCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM events", Integer.class);
        Integer seatCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM seats", Integer.class);

        assertTrue(eventCount != null && eventCount > 0, "Oracle event table should be seeded");
        assertTrue(seatCount != null && seatCount > 0, "Oracle seat table should be seeded");
    }
}
