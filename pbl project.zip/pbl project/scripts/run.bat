@echo off
setlocal
cd /d "%~dp0.."
if not exist .env copy .env.example .env
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
  if "%%A"=="TLS_KEYSTORE_PASSWORD" set "TLS_KEYSTORE_PASSWORD=%%B"
)
if not exist keystore.p12 (
  if not defined TLS_KEYSTORE_PASSWORD (
    echo TLS_KEYSTORE_PASSWORD must be set in .env
    exit /b 1
  )
  keytool -genkeypair -alias ticketrush -keyalg RSA -keysize 2048 -storetype PKCS12 -storepass "%TLS_KEYSTORE_PASSWORD%" -keypass "%TLS_KEYSTORE_PASSWORD%" -keystore keystore.p12 -dname "CN=localhost, OU=TicketRush, O=TicketRush, L=Local, ST=Local, C=US"
  if errorlevel 1 exit /b 1
)
docker compose up -d --build
