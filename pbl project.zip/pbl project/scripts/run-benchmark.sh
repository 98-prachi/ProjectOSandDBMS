#!/bin/bash
set -euo pipefail
./mvnw test -Dtest=BenchmarkServiceTest
