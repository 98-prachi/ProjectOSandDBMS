#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"
if [ ! -f .env ]; then cp .env.example .env; fi
if [ ! -f keystore.p12 ]; then
  TLS_KEYSTORE_PASSWORD="$(sed -n 's/^TLS_KEYSTORE_PASSWORD=//p' .env | head -n 1)"
  if [ -z "$TLS_KEYSTORE_PASSWORD" ]; then
    echo "TLS_KEYSTORE_PASSWORD must be set in .env" >&2
    exit 1
  fi
  keytool -genkeypair -alias ticketrush -keyalg RSA -keysize 2048 -storetype PKCS12 -storepass "$TLS_KEYSTORE_PASSWORD" -keypass "$TLS_KEYSTORE_PASSWORD" -keystore keystore.p12 -dname "CN=localhost, OU=TicketRush, O=TicketRush, L=Local, ST=Local, C=US"
fi
docker compose up -d --build
