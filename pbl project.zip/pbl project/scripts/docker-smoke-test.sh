#!/bin/bash
set -euo pipefail
curl -fk https://localhost:8443/actuator/health || exit 1
echo "Smoke test passed"
