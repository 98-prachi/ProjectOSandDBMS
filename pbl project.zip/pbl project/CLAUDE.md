Read AGENTS.md for the project source of truth and execution rules.
