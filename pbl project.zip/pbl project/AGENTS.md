# TicketRush AGENTS.md

## Project summary
TicketRush is a flash-sale booking system built to teach concurrency, locking, and transaction isolation. It benchmarks optimistic vs pessimistic locking while being a real, runnable Java Spring Boot application with a small responsive frontend.

## Stack
- Java 25 (LTS)
- Spring Boot 3.x
- Maven
- Spring Web, Data JPA, Security, Validation, Actuator
- H2 (default local profile) and MySQL 8 (Docker profile)
- JWT-based auth
- Flyway, OpenAPI, Bucket4j
- Vanilla HTML/CSS/JS frontend

## Folder map
- src/main/java/com/ticketrush/ ... application code
- src/main/resources/... application config, static frontend, migrations
- src/test/java/... tests
- docs/... architecture, API contract, security, progress, decisions
- scripts/... run and benchmark helpers

## Build, run, test
- ./mvnw test
- ./mvnw spring-boot:run -Dspring-boot.run.profiles=h2
- docker compose up -d --build

## Security rules
- No secrets in code or git history.
- Validate every request.
- Authorize booking operations on authenticated user identity.
- Log security events and failures to audit records.
- Default to H2 for local runs when Docker is unavailable.

## Coding conventions
- Keep classes small and package by layer.
- Prefer explicit named methods over hidden magic.
- Document non-obvious concurrency choices in code comments.
- Update docs/PROGRESS.md after every completed task.

## Definition of done
- Code compiles and tests pass.
- API contract is implemented and documented.
- Frontend works end to end for the happy path.
- Concurrency benchmark is present and reports real results.
- Docs reflect actual status.

## Mandatory rules
- Read AGENTS.md, docs/ARCHITECTURE.md, docs/API_CONTRACT.md, docs/SECURITY.md and docs/PROGRESS.md before changing anything.
- Update docs/PROGRESS.md after every completed task.
