# TicketRush Copilot Instructions

Project summary: TicketRush is a Java 25 LTS + Spring Boot 3 demo for flash-sale booking concurrency.

Stack: Spring Boot 3.x, Java 25 LTS, Maven, Spring Web, JPA, Spring Security, JWT, H2/MySQL, OpenAPI, Bucket4j, vanilla JS frontend.

Build and run:
- ./mvnw test
- ./mvnw spring-boot:run -Dspring-boot.run.profiles=h2

Security rules:
- never commit secrets or .env values
- validate all authorization and validation logic
- prefer explicit, small controller/service methods

Mandatory rules:
- read AGENTS.md, docs/ARCHITECTURE.md, docs/API_CONTRACT.md, docs/SECURITY.md and docs/PROGRESS.md before changing anything
- update docs/PROGRESS.md after every completed task
