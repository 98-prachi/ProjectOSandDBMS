# Continue prompt

Read AGENTS.md and the docs folder first. Build and test the real project state before editing. Resume from the first unchecked item in docs/PROGRESS.md and complete it before moving on.
