# Concurrency instructions

- Respect locking strategy and retry semantics in booking flows.
- Keep seat reservation decisions atomic and ordered.
- Use explicit version checks for optimistic locking.
- Measure and report real benchmark numbers, never fabricated values.
