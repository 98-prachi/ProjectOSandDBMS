# Security instructions

- Validate JWT and role checks before all booking endpoints.
- Never trust request input; validate DTOs and role constraints.
- Use secure password hashing with BCrypt.
- Log security-relevant actions to the audit trail.
