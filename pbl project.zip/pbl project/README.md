# TicketRush

TicketRush is a flash-sale ticket booking engine designed to highlight concurrency control in a real Java/Spring Boot project. It demonstrates optimistic locking, pessimistic locking, and transaction isolation behaviors under load.

## Team
- Prachi Rana (lead)
- Kamaldeep Singh
- Reet Sharma
- Aditya Rawat

## Stack
Java 25 LTS, Spring Boot 3, Spring Security, Spring Data JPA, H2, Oracle, JWT, OpenAPI, Bucket4j, vanilla HTML/JS UI.

## Local run
1. Copy `.env.example` to `.env`; the local `.env` file is loaded by Spring Boot and is ignored by git.
2. Generate a local HTTPS keystore if `keystore.p12` is missing. The password must match `TLS_KEYSTORE_PASSWORD` in `.env`; for the example settings, run:
   `keytool -genkeypair -alias ticketrush -keyalg RSA -keysize 2048 -storetype PKCS12 -storepass change_me -keypass change_me -keystore keystore.p12 -dname "CN=localhost, OU=TicketRush, O=TicketRush, L=Local, ST=Local, C=US"`
3. Run with the H2 profile: `./mvnw spring-boot:run -Dspring-boot.run.profiles=h2`
4. Or run against Oracle Free: `./mvnw spring-boot:run -Dspring-boot.run.profiles=oracle`
5. Open: https://localhost:8443

The Oracle profile expects the `FREEPDB1` service and a dedicated `TICKRUSH_APP` schema user. Set `SPRING_DATASOURCE_PASSWORD` in `.env` before using the Oracle profile.

## Docker run
1. The Windows (`scripts\run.bat`) and Linux/macOS (`./scripts/run.sh`) launchers create a local HTTPS keystore when needed, then run `docker compose up -d --build`. You can also create the keystore manually before running Compose directly.
2. Open: https://localhost:8443

## Benchmark
Use the benchmark API in the UI or call the /api/benchmark/run endpoint.
