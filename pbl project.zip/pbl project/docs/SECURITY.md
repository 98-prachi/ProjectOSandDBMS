# Security

- Passwords are hashed with BCrypt before storage.
- JWT bearer tokens are validated when supplied; protected endpoints require a valid token.
- Role-based access control protects booking and benchmark endpoints.
- Bucket4j rate limiting is optional but included to reduce abuse.
- Audit log records booking events and failed login attempts.
- The landing page and static frontend assets are public so users can reach the login and registration screens; booking, audit, and benchmark operations remain protected.
