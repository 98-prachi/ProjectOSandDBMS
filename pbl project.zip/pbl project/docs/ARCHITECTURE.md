# Architecture

## Layers
- Presentation: REST controllers and static frontend
- Application: auth, booking, benchmark services
- Persistence: JPA repositories and entities
- Security: JWT validation, role checks, rate limiting

## ER diagram
```mermaid
 erDiagram
  USER ||--o{ REFRESH_TOKEN : has
  USER ||--o{ BOOKING : makes
  EVENT ||--o{ SEAT : has
  EVENT ||--o{ BOOKING : contains
  SEAT ||--o{ BOOKING : is_booked
```

## Sequence: optimistic locking
```mermaid
sequenceDiagram
  participant Client
  participant API
  participant DB
  Client->>API: Hold seat
  API->>DB: SELECT seat WHERE id = ?
  DB-->>API: Seat + version
  API->>DB: UPDATE seat SET status = 'HELD', version = version + 1 WHERE id = ? AND version = ?
  alt row count = 1
    DB-->>API: Success
  else row count = 0
    API-->>Client: 409 Conflict
  end
```

## Sequence: pessimistic locking
```mermaid
sequenceDiagram
  participant Client
  participant API
  participant DB
  Client->>API: Hold seat
  API->>DB: SELECT ... FOR UPDATE
  DB-->>API: Locked row
  API->>DB: UPDATE seat status = 'HELD'
  DB-->>API: Commit
```

## Deployment
```mermaid
flowchart LR
  Browser --> App
  App --> Oracle
  App --> JWT
```

## Design rationale
H2 is the default local profile for zero setup; Oracle is the production-oriented benchmark target when a full enterprise DBMS is required. The seat table keeps constraints and versioning so that holding a seat is a single atomic DB decision.
