# Architecture decisions

- Default local execution uses H2 because Docker and Maven were unavailable in the initial environment.
- Seat state is stored in a single table with optimistic versioning and explicit hold expiration.
- Benchmarking runs against the live database layer to produce real transaction timings.
- A static Vanilla JS frontend is used to keep the project demo-friendly and build-free.
