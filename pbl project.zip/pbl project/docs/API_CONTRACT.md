# API Contract

## Authentication

### POST /api/auth/register
- Role: Public
- Request: {"name":"Alice","email":"alice@example.com","password":"abc123"}
- Response: {"token":"...","refreshToken":"..."}
- Errors: 400 invalid data, 409 email exists

### POST /api/auth/login
- Role: Public
- Request: {"email":"alice@example.com","password":"abc123"}
- Response: {"token":"...","refreshToken":"...","user":{"id":1,"email":"alice@example.com","role":"USER"}}
- Errors: 401 invalid credentials

### POST /api/auth/refresh
- Role: Public
- Request: {"refreshToken":"..."}
- Response: {"token":"...","refreshToken":"..."}

## Events

### GET /api/events
- Role: Public
- Response: [{"id":1,"name":"Music Fest","venue":"Delhi","eventTime":"2026-11-30T18:00:00","totalSeats":50}]

### GET /api/events/{id}/seats
- Role: Public
- Response: [{"id":1,"seatNumber":"A1","price":500,"status":"AVAILABLE","version":0}]

## Booking

### POST /api/bookings/hold
- Role: USER
- Request: {"eventId":1,"seatId":1}
- Response: {"bookingId":1,"status":"HELD","seatNumber":"A1","expiresAt":"..."}
- Errors: 409 seat unavailable, 404 event not found

### POST /api/bookings/confirm
- Role: USER
- Request: {"bookingId":1}
- Response: {"bookingId":1,"status":"CONFIRMED"}

### POST /api/bookings/cancel
- Role: USER
- Request: {"bookingId":1}
- Response: {"bookingId":1,"status":"CANCELLED"}

### GET /api/audit
- Role: USER or ADMIN
- Response: [{"id":1,"action":"SEAT_HELD","message":"Seat A1 held"}]

## Benchmark

### POST /api/benchmark/run
- Role: ADMIN
- Request: {"strategy":"OPTIMISTIC","concurrency":12,"attemptsPerThread":20,"eventId":1}
- Response: {"strategy":"OPTIMISTIC","successCount":240,"failureCount":0,"throughputPerSecond":126.0,"averageLatencyMs":15.3}

## Error model
- 400 Bad request
- 401 Unauthorized
- 403 Forbidden
- 404 Not found
- 409 Conflict
- 500 Internal server error
